package TP9.MisVideos;

public abstract class Filtro {
    public abstract boolean cumple(Video v1);
}
