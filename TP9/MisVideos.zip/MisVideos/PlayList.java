package TP9.MisVideos;

import java.util.ArrayList;
import java.util.Comparator;

public class PlayList extends Elemento {

    private ArrayList<Elemento> elementos;

    public PlayList(String titulo) {
        super(titulo);
        elementos = new ArrayList<Elemento>();
    }

    public ArrayList<Video> buscar(Filtro f1, Comparator<Usuario> comparator) {

        ArrayList<Video> aux = new ArrayList<Video>();
        for (Elemento e : elementos) {

            ArrayList<Video> result = e.buscar(f1, null);

            int i = 0;
            if (aux.isEmpty())
                aux.addAll(result);
            else {
                if (result.size() > 0) {
                    while (i < aux.size()
                            && (comparator.compare(result.get(i).getUsuario(), aux.get(i).getUsuario())) > 0) {
                        i++;
                    }
                    if (i < aux.size()) {
                        aux.addAll(result);
                    } else {
                        aux.addAll(result);
                    }
                }
            }
        }
        return aux;
    }

    public void addElemento(Elemento e1) {
        elementos.add(e1);
    }

}
