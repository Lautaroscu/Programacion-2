package TP9.MisVideos;

import java.util.Comparator;

public class ComparadorUsuario implements Comparator<Usuario> {
    public int compare(Usuario usuario1, Usuario usuario2) {
        if (usuario1.getNombre().compareTo(usuario2.getNombre()) > 0) {
            return 1;
        } else if (usuario1.getNombre().compareTo(usuario2.getNombre()) < 0)
            return -1;
        return 0;
    }
}
